//>>built
define("dgrid/extensions/nls/pagination",{root:{status:"${start} - ${end} of ${total} results"},es:true,ja:true});