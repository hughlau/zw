//>>built
define("dijit/form/nls/pt-pt/ComboBox",({previousMessage:"Opções anteriores",nextMessage:"Mais opções"}));